import React from 'react';

function Home() {
    return (
        <h1>Welcome!</h1>
    );
}

export default Home;