import React from 'react';

function Number(props) {
    const {num} = props;

    return (
        <h1>The number is: {num}</h1>
    );
}

export default Number;