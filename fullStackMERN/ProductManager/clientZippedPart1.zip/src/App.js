import React from 'react';
import Product from './views/Product';

function App() {
  return (
    <div className="App">
      <Product />
    </div>
  );
}
export default App;