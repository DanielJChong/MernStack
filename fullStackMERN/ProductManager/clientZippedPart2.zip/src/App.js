import React from 'react';
import { Router, Redirect } from '@reach/router';

import Product from './views/Product';
import ProductDetail from './views/ProductDetail';


function App() {
  return (
    <div className="App">
      <Router>
        <Product path="/product"/>
        <ProductDetail path="/product/:id" />
        <Redirect from="/" to="/product" noThrow/>
      </Router>
    </div>
  );
}

export default App;